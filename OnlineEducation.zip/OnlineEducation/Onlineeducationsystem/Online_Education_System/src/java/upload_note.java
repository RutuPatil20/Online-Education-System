/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author HP
 */
public class upload_note extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out=resp.getWriter();
        String  id=req.getParameter("ID");
        String  cname=req.getParameter("Name");
        String  fname=req.getParameter("txt_filename");
        String  uploder=req.getParameter("Upload");
        String  desc=req.getParameter("txt_description");

        out.println(id);
         out.println(cname);
        out.println(fname);
        out.println(uploder);
        out.println(desc);

        database db=new database();
        String result=db.connectdb();
        out.println(result);


    }

}
