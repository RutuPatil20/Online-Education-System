/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author HP
 */
public class fead_lect extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
         PrintWriter out=resp.getWriter();
         String id=req.getParameter("txt_studentid");
         String sname=req.getParameter("txt_studentname");
         String lname=req.getParameter("txt_lecturename");
         String query=req.getParameter("txt_query");
         String sol=req.getParameter("Solution");
            
         
         out.println(id);
         out.println(sname);
         out.println(lname);
         out.println(query);
         out.println(sol);


        database db=new database();
        String result=db.connectdb();
        out.println(result);


    }

}
