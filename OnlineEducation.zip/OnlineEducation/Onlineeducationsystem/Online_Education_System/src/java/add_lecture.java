/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author HP
 */
public class add_lecture extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out=resp.getWriter();
        String id=req.getParameter("id");
        String lecture=req.getParameter("txt-Name");
        String email=req.getParameter("txt_email");
        String username=req.getParameter("txt_usename");
        String password=req.getParameter("txt_pass");
        String Contact=req.getParameter("txt-no");
        String course=req.getParameter("Course");
        String deap=req.getParameter("Department");
         
        out.println(id);
        out.println(lecture);
        out.println(email);
        out.println(username);
        out.println(password);
        out.println(Contact);
        out.println(course);
        out.println(deap);


        database db=new database();
        String result=db.connectdb();
        out.println(result);



    }
}