/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author HP
 */
public class stud_reg extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out=resp.getWriter();
        String id=req.getParameter("id");
        String Sname=req.getParameter("student");
        String Address=req.getParameter("address");
        String email=req.getParameter("email");
        String contact=req.getParameter("no");
        String uname=req.getParameter("usename");
        String password=req.getParameter("pass");

        out.println(id);
        out.println(Sname);
        out.println(Address);
        out.println(email);
        out.println(contact);
        out.println(uname);
        out.println(password);
        
        
        database db=new database();
        String result=db.connectdb();
        out.println(result);



    }

}
