/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author HP
 */
public class fead_stud extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out=resp.getWriter();
        String id=req.getParameter("ID");
        String sname=req.getParameter("student");
        String lid=req.getParameter("lessonid");
        String Lname=req.getParameter("lessonname");
        String query=req.getParameter("txt_query");
         
        out.println(id);
        out.println(sname);
        out.println(lid);
        out.println(Lname);
        out.println(query);

        database db=new database();
        String result=db.connectdb();
        out.println(result);

           
    }
    
}