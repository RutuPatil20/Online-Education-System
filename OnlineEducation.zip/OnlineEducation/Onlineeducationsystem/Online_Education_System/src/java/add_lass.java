/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author HP
 */
public class add_lass extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
     PrintWriter out=resp.getWriter();
     String id=req.getParameter("id");
     String lname=req.getParameter("leasson");
     String Lecturename=req.getParameter("Lecture");
     String Cname=req.getParameter("Course");
     String Fname=req.getParameter("File");
     String description=req.getParameter("Description");
        
     out.println(id);
     out.println(lname);
     out.println(Lecturename);
     out.println(Cname);
     out.println(Fname);
     out.println(description);
     
            
     
        database db=new database();
        String result=db.connectdb();
        out.println(result);



    }
    
}


